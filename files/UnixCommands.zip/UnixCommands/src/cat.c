#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    char line[256];

    if (argc < 2)
    {
        fprintf(stderr, "Please specify a filename");
        exit(EXIT_FAILURE);
    }

    FILE *fp = fopen(argv[1], "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Cannot open file");
        exit(EXIT_FAILURE);
    }

    while (fgets(line, 256, fp) != NULL)
    {
        printf("%s", line);
    }
    fclose(fp);

    return EXIT_SUCCESS;
}