#include <stdlib.h>

int main(void)
{
    system("cls");
    return EXIT_SUCCESS;
}