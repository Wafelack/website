#include <stdlib.h>

int main(void)
{
    system("dir");
    return EXIT_SUCCESS;
}