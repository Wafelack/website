#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        fprintf(stderr, "Error, please specify 2 arguments");
        exit(EXIT_FAILURE);
    }

    char command[256];

    sprintf(command, "del %s", argv[1]);

    system(command);

    exit(EXIT_SUCCESS);
}