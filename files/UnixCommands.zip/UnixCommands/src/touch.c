#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        fprintf(stderr, "The correct syntax is : touch <filename>");
        exit(EXIT_FAILURE);
    }

    char cmd[256];

    sprintf(cmd, "echo %s >> %s", argv[1], argv[1]);

    system(cmd);
    exit(EXIT_SUCCESS);
}